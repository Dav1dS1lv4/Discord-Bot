// deploy-commands.js
require('dotenv').config();
const { REST, Routes } = require('discord.js');
const fs = require('node:fs');
const path = require('node:path');

const commands = [];
const adminPath = path.join(__dirname, 'commands', 'admin');
const files = fs.readdirSync(adminPath).filter(file => file.endsWith('.js'));

for (const file of files) {
  const filePath = path.join(adminPath, file);
  const command = require(filePath);

  if ('data' in command && 'execute' in command) {
    commands.push(command.data.toJSON());
    console.log(`Loaded: /${command.data.name}`);
  } else {
    console.warn(`[WARNING] Command at ${filePath} is missing 'data' or 'execute' property. Skipping this file.`);
  }
}

const rest = new REST().setToken(process.env.DISCORD_TOKEN);

(async () => {
  try {
    console.log('Started refreshing application (/) commands...');
    console.log('Clearing old commands...');

    // Clear existing commands
    await rest.put(
      Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
      { body: [] }
    );

    // Register new commands
    console.log(`Registering ${commands.length} command(s)...`);
    await rest.put(
      Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
      { body: commands }
    );

    console.log('Successfully registered all application commands!');
  } catch (error) {
    console.error('Failed to register commands:', error);
  }
})();