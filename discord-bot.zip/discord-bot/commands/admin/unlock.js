require('dotenv').config();
const { SlashCommandBuilder, EmbedBuilder, ChannelType } = require('discord.js');

const ALLOWED_ROLES = ['']; // Add the ID roles that can use the command.
const LOG_CHANNEL_ID = 'LOG_ID';

const EXEMPT_CHANNELS = [
  'CHOOSE CHANNELS FOR EXEPTIONS'
];

const safeDelete = (interaction) => {
  setTimeout(async () => {
    try {
      if (interaction.deferred || interaction.replied) {
        await interaction.deleteReply();
      }
    } catch (error) {
      if (error.code !== 10008) console.error('Failed to delete reply:', error);
    }
  }, 12000);
};


module.exports = {
  data: new SlashCommandBuilder()
    .setName('unlock')
    .setDescription('Unlocks only channels that were previously locked'),

  async execute(interaction) {
    if (!ALLOWED_ROLES.some(r => interaction.member.roles.cache.has(r))) {
      return interaction.reply({ content: 'You do not have permission.', ephemeral: true });
    }

    await interaction.deferReply({ ephemeral: true });

    const channelsToCheck = interaction.guild.channels.cache.filter(
      c => c.type === ChannelType.GuildText && !EXEMPT_CHANNELS.includes(c.id)
    );

    let unlocked = 0;
    for (const channel of channelsToCheck.values()) {
      try {
        const overwrite = channel.permissionOverwrites.cache.get(interaction.guild.roles.everyone.id);
        if (overwrite?.deny.has('SendMessages')) {
          await channel.permissionOverwrites.delete(interaction.guild.roles.everyone.id);
          unlocked++;
        }
      } catch (_) {}
    }

    const embed = new EmbedBuilder()
      .setColor('#00FF00')
      .setTitle('LOCKDOWN DEACTIVATED')
      .setDescription(`**${unlocked}** channels unlocked.\nExempt channels were not modified.`)
      .setTimestamp()
      .setFooter({ text: `By ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() });

    await interaction.editReply({ embeds: [embed] });

    setTimeout(async () => {
      try { await interaction.deleteReply(); } catch (e) { if (e.code !== 10008) console.error(e); }
    }, 12000);

    const log = interaction.guild.channels.cache.get(LOG_CHANNEL_ID);
    if (log) {
      log.send({
        embeds: [new EmbedBuilder()
          .setColor('#00FF00')
          .setTitle('Lockdown Deactivated')
          .setDescription(`**Moderator**: ${interaction.user}\n**Channels unlocked**: ${unlocked}`)
          .setTimestamp()]
      }).catch(() => {});
    }
  }
};