const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');
const fs = require('fs');

const ALLOWED_ROLES = ['']; // Add the ID roles that can use the command.

module.exports = {
    data: new SlashCommandBuilder()
        .setName('unban')
        .setDescription('Removes a ban from user.')
        .addStringOption(option =>
            option.setName('user_id')
                .setDescription('User ID to be unbanned')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Reason for the unban')
                .setRequired(false)),
    async execute(interaction) {
        if (!ALLOWED_ROLES.some(roleId => interaction.member.roles.cache.has(roleId))) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Permission Error')
                .setDescription('You do not have permission to unban members!')
                .setTimestamp();
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        if (!interaction.guild.members.me.permissions.has(PermissionsBitField.Flags.BanMembers)) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Permission Error')
                .setDescription('I do not have permission to unban members!')
                .setTimestamp();
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        const userId = interaction.options.getString('user_id');
        const reason = interaction.options.getString('reason') || 'No reason provided';

        if (!/^\d+$/.test(userId)) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Invalid ID')
                .setDescription('Please provide a valid user ID (Numbers Only)!')
                .setTimestamp();
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        try {
            const banList = await interaction.guild.bans.fetch();
            const bannedUser = banList.get(userId);

            if (!bannedUser) {
                const errorEmbed = new EmbedBuilder()
                    .setColor('#FF0000')
                    .setTitle('User not banned')
                    .setDescription('This user is not banned from the server!')
                    .setTimestamp();
                return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }

            let gifs = { ban: '', kick: '', unban: '' };
            try {
                gifs = JSON.parse(fs.readFileSync('./data/gifs.json'));
            } catch (error) {
                console.error('Error loading gifs.json:', error);
            }

            const unbanGif = gifs.unban || 'https://media.giphy.com/media/l0IylOPCNkiqOgMyA/giphy.gif';

            await interaction.guild.members.unban(userId, reason);

            const successEmbed = new EmbedBuilder()
                .setColor('#00FF00')
                .setTitle('User unbanned')
                .setDescription(`User with ID: ${userId} has been successfully unbanned!`)
                .addFields(
                    { name: 'Reason', value: reason, inline: true },
                    { name: 'Moderator', value: interaction.user.tag, inline: true }
                )
                .setImage(unbanGif)
                .setTimestamp();

            const replyMessage = await interaction.reply({
                embeds: [successEmbed],
                fetchReply: true
            });

            setTimeout(() => {
                replyMessage.delete().catch(error => {
                    console.error('Error deleting message:', error);
                });
            }, 15000);
        } catch (error) {
            console.error('Error while unbanning:', error);
            const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Error unbanning')
                .setDescription('Error unbanning the user! Check if the ID is correct or I have sufficient permissions.')
                .setTimestamp();
            await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
    }
};