require('dotenv').config();
const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');

const modLogChannelId = process.env.MOD_LOG_CHANNEL_ID; // Set this in .env

module.exports = {
  // mutechat command
  mutechat: {
    data: new SlashCommandBuilder()
      .setName('mutechat')
      .setDescription('Mute a user in text channels for a specified duration')
      .addUserOption(option =>
        option.setName('target')
          .setDescription('The user to mute')
          .setRequired(true))
      .addIntegerOption(option =>
        option.setName('duration')
          .setDescription('Duration in minutes (max 1440)')
          .setRequired(true)
          .setMinValue(1)
          .setMaxValue(1440))
      .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
    async execute(interaction) {
      const target = interaction.options.getUser('target');
      const duration = interaction.options.getInteger('duration') * 60 * 1000; // Convert to milliseconds
      const member = interaction.guild.members.cache.get(target.id);

      if (!member) {
        return interaction.reply({ content: 'User not found in this server.', ephemeral: true });
      }

      if (!member.moderatable) {
        return interaction.reply({ content: 'I don’t have permission to mute this user.', ephemeral: true });
      }

      await member.timeout(duration, `Muted by ${interaction.user.tag} for ${duration / 60000} minutes`);
      const embed = new EmbedBuilder()
        .setColor('#FFFF00')
        .setTitle('Text Mute Applied')
        .setDescription(`${target.tag} has been muted in text channels for ${duration / 60000} minutes.`)
        .setTimestamp()
        .setFooter({ text: `Action by ${interaction.user.tag}` });
      await interaction.reply({ embeds: [embed] });

      // Log to mod channel
      await logToModChannel(interaction, 'Text Mute', target, duration / 60000, null);
    },
  },

  // mutecall command
  mutecall: {
    data: new SlashCommandBuilder()
      .setName('mutecall')
      .setDescription('Mute a user in voice channels for a specified duration')
      .addUserOption(option =>
        option.setName('target')
          .setDescription('The user to mute')
          .setRequired(true))
      .addIntegerOption(option =>
        option.setName('duration')
          .setDescription('Duration in minutes (max 1440)')
          .setRequired(true)
          .setMinValue(1)
          .setMaxValue(1440))
      .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
    async execute(interaction) {
      const target = interaction.options.getUser('target');
      const duration = interaction.options.getInteger('duration') * 60 * 1000; // Convert to milliseconds
      const member = interaction.guild.members.cache.get(target.id);

      if (!member) {
        return interaction.reply({ content: 'User not found in this server.', ephemeral: true });
      }

      if (!member.voice.serverMute) {
        return interaction.reply({ content: 'User is not in a voice channel or I can’t mute them.', ephemeral: true });
      }

      await member.voice.setMute(true, `Muted by ${interaction.user.tag} for ${duration / 60000} minutes`);
      setTimeout(() => member.voice.setMute(false), duration); // Unmute after duration
      const embed = new EmbedBuilder()
        .setColor('#FFFF00')
        .setTitle('Voice Mute Applied')
        .setDescription(`${target.tag} has been muted in voice channels for ${duration / 60000} minutes.`)
        .setTimestamp()
        .setFooter({ text: `Action by ${interaction.user.tag}` });
      await interaction.reply({ embeds: [embed] });

      // Log to mod channel
      await logToModChannel(interaction, 'Voice Mute', target, duration / 60000, null);
    },
  },

  // strike command (updated for automatic strike increment)
  strike: {
    data: new SlashCommandBuilder()
      .setName('strike')
      .setDescription('Apply an automatic strike to a user for rule-breaking with mute')
      .addUserOption(option =>
        option.setName('target')
          .setDescription('The user to strike')
          .setRequired(true))
      .addStringOption(option =>
        option.setName('reason')
          .setDescription('Reason for the strike')
          .setRequired(true))
      .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
    async execute(interaction) {
      const target = interaction.options.getUser('target');
      const reason = interaction.options.getString('reason');
      const member = interaction.guild.members.cache.get(target.id);

      if (!member) {
        return interaction.reply({ content: 'User not found in this server.', ephemeral: true });
      }

      if (!member.moderatable) {
        return interaction.reply({ content: 'I don’t have permission to manage this user.', ephemeral: true });
      }

      // Check existing strike roles
      const strikeRoles = ['strike 1', 'strike 2', 'strike 3'];
      const userRoles = member.roles.cache;
      let currentStrike = 0;
      if (userRoles.some(role => strikeRoles.includes(role.name))) {
        currentStrike = strikeRoles.indexOf(userRoles.find(role => strikeRoles.includes(role.name)).name.replace('strike ', '')) + 1;
      }

      // Determine next strike level
      let nextStrike = Math.min(currentStrike + 1, 3); // Caps at 3
      const strikeRole = interaction.guild.roles.cache.find(role => role.name === `strike ${nextStrike}`);
      if (!strikeRole) {
        return interaction.reply({ content: 'Strike role not found. Please create "strike 1", "strike 2", and "strike 3" roles.', ephemeral: true });
      }

      // Remove lower strike roles
      for (let i = 1; i < nextStrike; i++) {
        const lowerRole = interaction.guild.roles.cache.find(role => role.name === `strike ${i}`);
        if (lowerRole) await member.roles.remove(lowerRole);
      }

      // Assign the new strike role
      await member.roles.add(strikeRole);

      // Apply mute based on strike level
      let muteDuration = 0;
      switch (nextStrike) {
        case 1:
          muteDuration = 10 * 60 * 1000; // 10 minutes
          break;
        case 2:
          muteDuration = 20 * 60 * 1000; // 20 minutes
          break;
        case 3:
          muteDuration = 60 * 60 * 1000; // 1 hour
          break;
      }

      await member.timeout(muteDuration, `Strike ${nextStrike} by ${interaction.user.tag} for ${reason}`);
      const embed = new EmbedBuilder()
        .setColor('#FF0000')
        .setTitle(`Strike ${nextStrike} Applied`)
        .setDescription(`${target.tag} has received Strike ${nextStrike} for "${reason}". Muted for ${muteDuration / 60000} minutes.`)
        .setTimestamp()
        .setFooter({ text: `Action by ${interaction.user.tag}` });
      await interaction.reply({ embeds: [embed] });

      // Log to mod channel
      await logToModChannel(interaction, `Strike ${nextStrike}`, target, muteDuration / 60000, reason);

      // Unmute and remove role after duration
      setTimeout(async () => {
        await member.timeout(null); // Unmute
        await member.roles.remove(strikeRole); // Remove strike role
        // Optional reset to strike 1 after strike 3
        if (nextStrike === 3) {
          const strike1Role = interaction.guild.roles.cache.find(role => role.name === 'strike 1');
          if (strike1Role) await member.roles.add(strike1Role);
        }
      }, muteDuration);
    },
  },
};

// Helper function to log to mod channel
async function logToModChannel(interaction, actionType, target, duration, reason) {
  if (!modLogChannelId) {
    console.log('Mod log channel ID not set in .env');
    return;
  }

  const channel = interaction.guild.channels.cache.get(modLogChannelId);
  if (!channel) {
    console.log('Mod log channel not found');
    return;
  }

  const embed = new EmbedBuilder()
    .setColor('#000000')
    .setTitle(`${actionType} Logged`)
    .setDescription(
      `**Action**: ${actionType}\n` +
      `**User**: ${target.tag} (ID: ${target.id})\n` +
      `**Moderator**: ${interaction.user.tag}\n` +
      `**Duration**: ${duration ? `${duration} minutes` : 'N/A'}\n` +
      `**Reason**: ${reason || 'N/A'}\n` +
      `**Time**: ${new Date().toLocaleString('en-US', { timeZone: 'America/New_York' })}`
    )
    .setTimestamp();
  await channel.send({ embeds: [embed] });
}