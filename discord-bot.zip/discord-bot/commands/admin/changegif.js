const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');
const fs = require('fs');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('changegif')
        .setDescription('Changes the GIF displayed when banning, kicking or unbanning someone.')
        .addStringOption(option =>
            option.setName('type')
                .setDescription('Type of action (ban, kick or unban)')
                .setRequired(true)
                .addChoices(
                    { name: 'Ban', value: 'ban' },
                    { name: 'Kick', value: 'kick' },
                    { name: 'Unban', value: 'unban' }
                ))
        .addStringOption(option =>
            option.setName('gif')
                .setDescription('GIF URL')
                .setRequired(true)),
    async execute(interaction) {
        // Check user permissions
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Permission Error')
                .setDescription('You need to be an administrator to use this command!')
                .setTimestamp();
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        const type = interaction.options.getString('type');
        const gif = interaction.options.getString('gif');

        // Validate the GIF URL
        const urlRegex = /^(https?:\/\/.*\.(?:gif|png|jpg|jpeg))/i;
        if (!urlRegex.test(gif)) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Invalid URL')
                .setDescription('Please provide a valid GIF URL (must end with .gif, .png, .jpg or .jpeg)!')
                .setTimestamp();
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        try {
            // Load existing GIFs
            let gifs = { ban: '', kick: '', unban: '' };
            try {
                gifs = JSON.parse(fs.readFileSync('./data/gifs.json'));
            } catch (error) {
                console.error('Error loading gifs.json:', error);
            }

            // Update the GIF
            gifs[type] = gif;
            fs.writeFileSync('./data/gifs.json', JSON.stringify(gifs, null, 2));

            // Create success embed
            const successEmbed = new EmbedBuilder()
                .setColor('#00FF00')
                .setTitle('GIF Updated')
                .setDescription(`GIF for **${type}** successfully updated!`)
                .addFields(
                    { name: 'New URL', value: gif, inline: true },
                    { name: 'Moderator', value: interaction.user.tag, inline: true }
                )
                .setImage(gif) // Display the new GIF in the embed
                .setTimestamp();

            // Reply with embed
            const replyMessage = await interaction.reply({
                embeds: [successEmbed],
                fetchReply: true
            });

            // Delete the message after 15 seconds
            setTimeout(() => {
                replyMessage.delete().catch(error => {
                    console.error('Error deleting message:', error);
                });
            }, 15000);

        } catch (error) {
            console.error('Error saving the GIF:', error);
            const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Error Saving')
                .setDescription('Error saving the GIF! Please try again.')
                .setTimestamp();
            await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
    }
};