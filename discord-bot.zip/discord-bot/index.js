const { Client, GatewayIntentBits, Collection, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

// Function to shuffle an array
function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.MessageContent
    ]
});

// Store commands
client.commands = new Collection();

// Load commands from commands folder
const commandsPath = path.join(__dirname, 'commands');
const commandFolders = fs.readdirSync(commandsPath).filter(folder => fs.statSync(path.join(commandsPath, folder)).isDirectory());

for (const folder of commandFolders) {
    const folderPath = path.join(commandsPath, folder);
    const commandFiles = fs.readdirSync(folderPath).filter(file => file.endsWith('.js'));
    for (const file of commandFiles) {
        const filePath = path.join(folderPath, file);
        const command = require(filePath);
        // Verifica se o comando tem 'data' e 'execute'
        if ('data' in command && 'execute' in command) {
            client.commands.set(command.data.name, command);
        } else {
            console.log(`[WARNING] Command at ${filePath} is missing 'data' or 'execute' property. Skipping this file.`);
        }
    }
}

// Store the timeout ID to control it later
let autoMessageTimeout;

const CHANNEL_IDS = {
    general: process.env.CHANNEL_ID,
    rules: process.env.CHANNEL_RULES_ID,
    announcements: process.env.CHANNEL_ANNOUNCEMENTS_ID,
    workWithUs: process.env.CHANNEL_WORK_WITH_US_ID,
    ideas: process.env.CHANNEL_IDEAS_ID,
    questions: process.env.CHANNEL_QUESTIONS_ID
};
const AUTO_ROLE_ID = ''; // Auto-role ID
const MESSAGE_INTERVAL = 120000; // 2 minutes between sends
const DELETE_DELAY = 120000; // 2 minutes for auto-delete

// Function to create embeds dynamically
function createEmbed(type) {
    const currentTime = new Date().toLocaleTimeString();
    switch (type) {
        case 'rules':
            return new EmbedBuilder()
                .setTitle('📜 Server Rules')
                .setDescription(`Check the rules in ${`<#${CHANNEL_IDS.rules}>`}. Respect everyone and avoid spam or offenses!`)
                .setColor(0x2F3136)
                .setFooter({ text: `Updated at ${currentTime}` });
        case 'announcements':
            return new EmbedBuilder()
                .setTitle('📢 Announcements')
                .setDescription(`Stay updated with news in ${`<#${CHANNEL_IDS.announcements}>`}. Events and updates ahead!`)
                .setColor(0x7289DA)
                .setFooter({ text: `Updated at ${currentTime}` });
        case 'workWithUs':
            return new EmbedBuilder()
                .setTitle('💼 Work With Us')
                .setDescription(`Interested in joining the team? Learn more in ${`<#${CHANNEL_IDS.workWithUs}>`} or DM the staff!`)
                .setColor(0x2F3136)
                .setFooter({ text: `Updated at ${currentTime}` });
        case 'ideas':
            return new EmbedBuilder()
                .setTitle('💡 Ideas')
                .setDescription(`Have an idea? Share it in ${`<#${CHANNEL_IDS.ideas}>`} with the /suggest command!`)
                .setColor(0x7289DA)
                .setFooter({ text: `Updated at ${currentTime}` });
        case 'questions':
            return new EmbedBuilder()
                .setTitle('❓ Questions')
                .setDescription(`Got a question? Ask in ${`<#${CHANNEL_IDS.questions}>`} and get help!`)
                .setColor(0x2F3136)
                .setFooter({ text: `Updated at ${currentTime}` });
        default:
            return null;
    }
}

// Function to manage the embed cycle
async function sendNextEmbed(index = 0) {
    const channel = client.channels.cache.get(CHANNEL_IDS.general);
    if (!channel) {
        console.log('General channel not found!');
        return;
    }

    let embedTypes = ['rules', 'announcements', 'workWithUs', 'ideas', 'questions'];
    embedTypes = shuffleArray(embedTypes); // Shuffle the embed types for each cycle
    const embedType = embedTypes[index % embedTypes.length];
    const embed = createEmbed(embedType);
    if (!embed) return;

    const sentMessage = await channel.send({ embeds: [embed] });
    console.log(`Message sent at ${new Date().toLocaleTimeString()}. Scheduled to delete at ${new Date(Date.now() + DELETE_DELAY).toLocaleTimeString()}`);
    setTimeout(() => {
        console.log(`Attempting to delete message at ${new Date().toLocaleTimeString()}`);
        sentMessage.delete().catch(error => console.error('Delete failed:', error));
        sendNextEmbed((index + 1) % embedTypes.length);
    }, DELETE_DELAY);
}

// Event: Bot ready
client.once('ready', () => {
    console.log(`${client.user.tag} Online!`);

    // Start sending the first embed
    sendNextEmbed();
});

// Event: New member joins
client.on('guildMemberAdd', async member => {
    try {
        const role = member.guild.roles.cache.get(AUTO_ROLE_ID);
        if (role) {
            await member.roles.add(role);
            console.log(`Assigned role ${role.name} to ${member.user.tag}`);
        } else {
            console.log(`Role with ID ${AUTO_ROLE_ID} not found!`);
        }
    } catch (error) {
        console.error('Error assigning role:', error);
    }
});

// Event: Interaction with commands
client.on('interactionCreate', async interaction => {
    if (!interaction.isCommand()) return;

    const command = client.commands.get(interaction.commandName);
    if (!command) {
        console.error(`There was no command found like "${interaction.commandName}"`);
        return;
    }

    try {
        await command.execute(interaction);
    } catch (error) {
        console.error(`Erro ao executar ${interaction.commandName}:`, error);
        await interaction.reply({ content: 'Error executing the command!', ephemeral: true });
    }
});

// Login to Discord
client.login(process.env.DISCORD_TOKEN);