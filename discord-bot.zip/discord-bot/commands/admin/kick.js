const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');
const fs = require('fs');

const ALLOWED_ROLES = ['']; // Add the ID roles that can use the command.

module.exports = {
    data: new SlashCommandBuilder()
        .setName('kick')
        .setDescription('Kicks a user from the server.')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('User to be kicked')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Reason for the kick')
                .setRequired(false)),
    async execute(interaction) {
        // Check user permissions
        if (!ALLOWED_ROLES.some(roleId => interaction.member.roles.cache.has(roleId))) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Permission Error')
                .setDescription('You do not have permission to kick members!')
                .setTimestamp();
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        if (!interaction.guild.members.me.permissions.has(PermissionsBitField.Flags.KickMembers)) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Permission Error')
                .setDescription('I do not have permission to kick members!')
                .setTimestamp();
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        const user = interaction.options.getUser('user');
        const reason = interaction.options.getString('reason') || 'No reason provided';

        if (user.id === interaction.user.id) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Invalid Action')
                .setDescription('You cannot kick yourself!')
                .setTimestamp();
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
        if (user.id === interaction.client.user.id) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Invalid Action')
                .setDescription('I cannot kick myself!')
                .setTimestamp();
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        try {
            const member = await interaction.guild.members.fetch(user.id).catch(() => null);
            if (!member) {
                const errorEmbed = new EmbedBuilder()
                    .setColor('#FF0000')
                    .setTitle('User Not Found')
                    .setDescription('This user is not in the server!')
                    .setTimestamp();
                return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }

            const botMember = interaction.guild.members.me;
            if (member.roles.highest.position >= botMember.roles.highest.position) {
                const errorEmbed = new EmbedBuilder()
                    .setColor('#FF0000')
                    .setTitle('Insufficient Hierarchy')
                    .setDescription('I cannot kick this user because they have a role equal to or higher than mine!')
                    .setTimestamp();
                return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }

            let gifs = { ban: '', kick: '', unban: '' };
            try {
                gifs = JSON.parse(fs.readFileSync('./data/gifs.json'));
            } catch (error) {
                console.error('Error loading gifs.json:', error);
            }

            const kickGif = gifs.kick || 'https://media.giphy.com/media/3o7bu3X5oQ4Uyddr2M/giphy.gif';

            await member.kick(reason);

            const successEmbed = new EmbedBuilder()
                .setColor('#00FF00')
                .setTitle('User Kicked')
                .setDescription(`${user.tag} was successfully kicked!`)
                .addFields(
                    { name: 'Reason', value: reason, inline: true },
                    { name: 'Moderator', value: interaction.user.tag, inline: true }
                )
                .setImage(kickGif)
                .setTimestamp();

            // Reply with embed
            const replyMessage = await interaction.reply({
                embeds: [successEmbed],
                fetchReply: true
            });

            // Delete the message after 15 seconds
            setTimeout(() => {
                replyMessage.delete().catch(error => {
                    console.error('Error deleting message:', error);
                });
            }, 15000);
        } catch (error) {
            console.error('Error while kicking:', error);
            const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Error Kicking')
                .setDescription('Error kicking the user! Check if the user is in the server, if I have sufficient permissions, or if the user has a role higher than mine.')
                .setTimestamp();
            await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
    }
};