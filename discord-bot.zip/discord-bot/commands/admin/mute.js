require('dotenv').config();
const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

process.env.MOD_LOG_CHANNEL_ID = '1398023766449324143';

const ALLOWED_ROLES = ['']; // Add the ID roles that can use the command.
const MUTE_ROLE_ID = '';
const VOICE_MUTED_ROLE_ID = '';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mute')
    .setDescription('Mutes a user in text and/or voice for a specified duration')
    .addUserOption(option => 
      option.setName('target')
        .setDescription('The user to mute')
        .setRequired(true))
    .addIntegerOption(option => 
      option.setName('duration')
        .setDescription('Duration in minutes (max 1440)')
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(1440))
    .addStringOption(option => 
      option.setName('reason')
        .setDescription('Reason for muting')
        .setRequired(false)),
  async execute(interaction) {
    if (!ALLOWED_ROLES.some(roleId => interaction.member.roles.cache.has(roleId))) {
      await interaction.reply({ embeds: [new EmbedBuilder().setColor('#FF0000').setTitle('Permission Error').setDescription('You do not have permission to mute members!').setTimestamp()], ephemeral: true });
      return;
    }

    const target = interaction.options.getUser('target');
    const duration = interaction.options.getInteger('duration') * 60 * 1000;
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const voiceMute = interaction.options.getBoolean('voice') || false;
    let member;

    try {
      member = await interaction.guild.members.fetch(target.id);
    } catch (error) {
      await interaction.reply({ embeds: [new EmbedBuilder().setColor('#FF0000').setTitle('User Not Found').setDescription('User not found in this server.').setTimestamp()], ephemeral: true });
      return;
    }

    if (!member.moderatable) {
      await interaction.reply({ embeds: [new EmbedBuilder().setColor('#FF0000').setTitle('Permission Error').setDescription('I don’t have permission to mute this user.').setTimestamp()], ephemeral: true });
      return;
    }

    const muteRole = interaction.guild.roles.cache.get(MUTE_ROLE_ID);
    if (!muteRole) {
      await interaction.reply({ embeds: [new EmbedBuilder().setColor('#FF0000').setTitle('Role Error').setDescription('Muted role not found.').setTimestamp()], ephemeral: true });
      return;
    }

    await member.roles.add(muteRole);
    await member.timeout(duration, reason);

    if (voiceMute && member.voice.channel) {
      await member.voice.setMute(true, reason);
      const voiceMutedRole = interaction.guild.roles.cache.get(VOICE_MUTED_ROLE_ID);
      if (voiceMutedRole) await member.roles.add(voiceMutedRole);
    }

    setTimeout(async () => {
      if (member.roles.cache.has(MUTE_ROLE_ID)) await member.roles.remove(muteRole);
      if (voiceMute && member.voice.channel && member.roles.cache.has(VOICE_MUTED_ROLE_ID)) {
        await member.voice.setMute(false);
        const voiceMutedRole = interaction.guild.roles.cache.get(VOICE_MUTED_ROLE_ID);
        if (voiceMutedRole) await member.roles.remove(voiceMutedRole);
      }
      if (member.communicationDisabledUntilTimestamp > Date.now()) await member.timeout(null);
    }, duration);

    const embed = new EmbedBuilder()
      .setColor('#FFFF00')
      .setTitle('Mute Applied')
      .setDescription(`${target.tag} has been muted for ${duration / 60000} minutes. ${voiceMute ? 'Voice mute included.' : 'Text mute only.'}`)
      .addFields({ name: 'Reason', value: reason, inline: true }, { name: 'Moderator', value: interaction.user.tag, inline: true })
      .setTimestamp();
    const replyMessage = await interaction.reply({ embeds: [embed] });
    setTimeout(() => {
      replyMessage.delete().catch(error => console.error('Error deleting message:', error));
    }, 10000); 

    await logToModChannel(interaction, 'Mute', target, duration / 60000, reason);
  },
};

// Helper function to log to mod channel
async function logToModChannel(interaction, actionType, target, duration, reason) {
  if (!process.env.MOD_LOG_CHANNEL_ID) return;
  const channel = interaction.guild.channels.cache.get(process.env.MOD_LOG_CHANNEL_ID);
  if (!channel) return;
  await channel.send({ embeds: [new EmbedBuilder()
    .setColor('#000000')
    .setTitle(`${actionType} Logged`)
    .setDescription(
      `**Action**: ${actionType}\n` +
      `**User**: ${target.tag} (ID: ${target.id})\n` +
      `**Moderator**: ${interaction.user.tag} (ID: ${interaction.user.id})\n` +
      `**Duration**: ${duration} minutes\n` +
      `**Reason**: ${reason}\n` +
      `**Time**: ${new Date().toLocaleString('en-US', { timeZone: 'America/New_York' })}`
    )
    .setTimestamp()] });
}