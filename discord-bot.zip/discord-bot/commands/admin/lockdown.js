require('dotenv').config();
const { SlashCommandBuilder, EmbedBuilder, ChannelType } = require('discord.js');

const ALLOWED_ROLES = ['']; // Add the ID roles that can use the command.
const LOG_CHANNEL_ID = '';

const EXEMPT_CHANNELS = [
  '',
  '',
  ''
];

const safeDelete = (interaction) => {
  setTimeout(async () => {
    try {
      if (interaction.deferred || interaction.replied) {
        await interaction.deleteReply();
      }
    } catch (error) {
      if (error.code !== 10008) console.error('Failed to delete reply:', error);
    }
  }, 12000);
};


module.exports = {
  data: new SlashCommandBuilder()
    .setName('lockdown')
    .setDescription('Locks all text channels except exempt ones'),

  async execute(interaction) {
       // Check user permissions
    if (!ALLOWED_ROLES.some(r => interaction.member.roles.cache.has(r))) {
      return interaction.reply({ content: 'You do not have permission.', ephemeral: true });
    }

    await interaction.deferReply({ ephemeral: true });

    const textChannels = interaction.guild.channels.cache.filter(
      c => c.type === ChannelType.GuildText && !EXEMPT_CHANNELS.includes(c.id)
    );

    let locked = 0;
    for (const channel of textChannels.values()) {
      try {
        await channel.permissionOverwrites.edit(
          interaction.guild.roles.everyone,
          { SendMessages: false },
          { reason: `Lockdown by ${interaction.user.tag}` }
        );
        locked++;
      } catch (_) {}
    }

    const embed = new EmbedBuilder()
      .setColor('#FF0000')
      .setTitle('LOCKDOWN ACTIVATED')
      .setDescription(`**${locked}** channels locked.\n**${EXEMPT_CHANNELS.length}** exempt channels remain open.`)
      .setTimestamp()
      .setFooter({ text: `By ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() });

    await interaction.editReply({ embeds: [embed] });

    setTimeout(async () => {
      try { await interaction.deleteReply(); } catch (e) { if (e.code !== 10008) console.error(e); }
    }, 12000);

    const log = interaction.guild.channels.cache.get(LOG_CHANNEL_ID);
    if (log) {
      log.send({
        embeds: [new EmbedBuilder()
          .setColor('#FF0000')
          .setTitle('Lockdown Activated')
          .setDescription(`**Moderator**: ${interaction.user}\n**Channels locked**: ${locked}\n**Exempt channels**: ${EXEMPT_CHANNELS.length}`)
          .setTimestamp()]
      }).catch(() => {});
    }
  }
};