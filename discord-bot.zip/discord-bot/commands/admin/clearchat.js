const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');
const fs = require('fs');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('clearchat')
        .setDescription('Clears a specified number of messages from the channel.')
        .addIntegerOption(option =>
            option.setName('amount')
                .setDescription('Number of messages to be deleted (1-100)')
                .setRequired(true)
                .setMinValue(1)
                .setMaxValue(300)),
    async execute(interaction) {
        // Check user permissions
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Permission Error')
                .setDescription('You do not have permission to manage messages!')
                .setTimestamp();
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        // Check bot permissions
        if (!interaction.guild.members.me.permissionsIn(interaction.channel).has(PermissionsBitField.Flags.ManageMessages)) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Permission Error')
                .setDescription('I do not have permission to manage messages in this channel!')
                .setTimestamp();
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        const amount = interaction.options.getInteger('amount');

        // Check amount (although setMinValue and setMaxValue already restrict this)
        if (amount < 1 || amount > 100) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Invalid Amount')
                .setDescription('The amount must be between 1 and 100!')
                .setTimestamp();
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        try {
            // Defer the reply
            await interaction.deferReply({ ephemeral: true });

            const channel = interaction.channel;
            const messages = await channel.bulkDelete(amount, true);

            // Load custom GIF
            let gifs = { ban: '', kick: '', unban: '', clearchat: '' };
            try {
                gifs = JSON.parse(fs.readFileSync('./data/gifs.json'));
            } catch (error) {
                console.error('Error loading gifs.json:', error);
            }

            const clearGif = gifs.clearchat || 'https://media.giphy.com/media/3o7bu3X5oQ4Uyddr2M/giphy.gif';

            // Create public confirmation embed
            const successEmbed = new EmbedBuilder()
                .setColor('#00FF00')
                .setTitle('Messages Deleted')
                .setDescription(`${messages.size} messages were successfully deleted!`)
                .addFields(
                    { name: 'Amount', value: `${messages.size}`, inline: true },
                    { name: 'Moderator', value: interaction.user.tag, inline: true }
                )
                .setImage(clearGif)
                .setTimestamp();

            // Send public message with the embed
            const confirmationMessage = await channel.send({
                embeds: [successEmbed]
            });


            // Delete the public message after 15 seconds
            setTimeout(() => {
                confirmationMessage.delete().catch(error => {
                    console.error('Error deleting confirmation message:', error);
                });
            }, 15000);

            // Delete the ephemeral message after 15 seconds
            setTimeout(() => {
                interaction.deleteReply().catch(error => {
                    console.error('Error deleting ephemeral response:', error);
                });
            }, 15000);

        } catch (error) {
            console.error('Error clearing messages:', error);
            const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Error Clearing')
                .setDescription('Error clearing messages! Check if I have permissions or if the messages are less than 14 days old.')
                .setTimestamp();
            await interaction.editReply({ embeds: [errorEmbed] });
        }
    }
};