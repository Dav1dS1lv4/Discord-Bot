const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');
const fs = require('fs');

const ALLOWED_ROLES = ['']; // Add the ID roles that can use the command.

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ban')
        .setDescription('Bans a user from the server.')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('User to be banned')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Reason for the ban')
                .setRequired(false)),
    async execute(interaction) {
        // Check user permissions
        if (!ALLOWED_ROLES.some(roleId => interaction.member.roles.cache.has(roleId))) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Permission Error')
                .setDescription('You do not have permission to ban members!')
                .setTimestamp();
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        if (!interaction.guild.members.me.permissions.has(PermissionsBitField.Flags.BanMembers)) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Permission Error')
                .setDescription('I do not have permission to ban members!')
                .setTimestamp();
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        const user = interaction.options.getUser('user');
        const reason = interaction.options.getString('reason') || 'No reason provided';

        if (user.id === interaction.client.user.id) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Invalid Action')
                .setDescription('I cannot ban myself!')
                .setTimestamp();
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
        if (user.id === interaction.user.id) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Invalid Action')
                .setDescription('You cannot ban yourself!')
                .setTimestamp();
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        try {
            let gifs = { ban: '', kick: '', unban: '' };
            try {
                gifs = JSON.parse(fs.readFileSync('./data/gifs.json'));
            } catch (error) {
                console.error('Error loading gifs.json:', error);
            }

            const banGif = gifs.ban || 'https://media.giphy.com/media/3o7bu3X5oQ4Uyddr2M/giphy.gif';

            await interaction.guild.members.ban(user, { reason });

            const successEmbed = new EmbedBuilder()
                .setColor('#00FF00')
                .setTitle('User Banned')
                .setDescription(`${user.tag} was successfully banned!`)
                .addFields(
                    { name: 'Reason', value: reason, inline: true },
                    { name: 'Moderator', value: interaction.user.tag, inline: true }
                )
                .setImage(banGif)
                .setTimestamp();
                
            // Reply with embed
            const replyMessage = await interaction.reply({
                embeds: [successEmbed],
                fetchReply: true
            });

            // Delete the message after 15 seconds
            setTimeout(() => {
                replyMessage.delete().catch(error => {
                    console.error('Error deleting message:', error);
                });
            }, 15000);
        } catch (error) {
            console.error('Error while banning:', error);
            const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Error Banning')
                .setDescription('Error banning the user! Check if the user is in the server or if I have sufficient permissions.')
                .setTimestamp();
            await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
    }
};