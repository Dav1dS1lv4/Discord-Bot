require('dotenv').config();
const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

process.env.MOD_LOG_CHANNEL_ID = '';

const ALLOWED_ROLES = ['']; // Add the ID roles that can use the command.
const STRIKE_ROLE_IDS = {
    strike1: 'STRIKEID1',
    strike2: 'STRIKEID2',
    strike3: 'STRIKEID3'
};
const MUTE_ROLE_ID = 'MUTE_ID';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('strike')
        .setDescription('Apply an automatic strike to a user for rule-breaking with mute')
        .addUserOption(option =>
            option.setName('target')
                .setDescription('The user to strike')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Reason for the strike')
                .setRequired(true)),
    async execute(interaction) {
        if (!ALLOWED_ROLES.some(roleId => interaction.member.roles.cache.has(roleId))) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Permission Error')
                .setDescription('You do not have permission to moderate members!')
                .setTimestamp();
            const replyMessage = await interaction.reply({ embeds: [errorEmbed] });
            setTimeout(() => {
                replyMessage.delete().catch(error => {
                    console.error('Error deleting message:', error);
                });
            }, 8000);
            return;
        }

        const target = interaction.options.getUser('target');
        const reason = interaction.options.getString('reason');
        const member = interaction.guild.members.cache.get(target.id);

        if (!member) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('User Not Found')
                .setDescription('User not found in this server.')
                .setTimestamp();
            const replyMessage = await interaction.reply({ embeds: [errorEmbed] });
            setTimeout(() => {
                replyMessage.delete().catch(error => {
                    console.error('Error deleting message:', error);
                });
            }, 8000);
            return;
        }

        if (!member.moderatable) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Permission Error')
                .setDescription('I don’t have permission to manage this user.')
                .setTimestamp();
            const replyMessage = await interaction.reply({ embeds: [errorEmbed] });
            setTimeout(() => {
                replyMessage.delete().catch(error => {
                    console.error('Error deleting message:', error);
                });
            }, 8000);
            return;
        }

        const userRoles = member.roles.cache;
        let currentStrike = 0;
        if (userRoles.has(STRIKE_ROLE_IDS.strike3)) currentStrike = 3;
        else if (userRoles.has(STRIKE_ROLE_IDS.strike2)) currentStrike = 2;
        else if (userRoles.has(STRIKE_ROLE_IDS.strike1)) currentStrike = 1;

        let nextStrike = Math.min(currentStrike + 1, 3);
        let strikeRoleId = null;
        let muteDuration = 0;

        switch (nextStrike) {
            case 1:
                strikeRoleId = STRIKE_ROLE_IDS.strike1;
                muteDuration = 10 * 60 * 1000;
                break;
            case 2:
                strikeRoleId = STRIKE_ROLE_IDS.strike2;
                muteDuration = 20 * 60 * 1000;
                break;
            case 3:
                strikeRoleId = STRIKE_ROLE_IDS.strike3;
                muteDuration = 60 * 60 * 1000;
                break;
        }

        const strikeRole = interaction.guild.roles.cache.get(strikeRoleId);
        if (!strikeRole) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Role Not Found')
                .setDescription('Strike role not found.')
                .setTimestamp();
            const replyMessage = await interaction.reply({ embeds: [errorEmbed] });
            setTimeout(() => {
                replyMessage.delete().catch(error => {
                    console.error('Error deleting message:', error);
                });
            }, 8000);
            return;
        }

        if (userRoles.has(STRIKE_ROLE_IDS.strike1) && nextStrike > 1) await member.roles.remove(STRIKE_ROLE_IDS.strike1);
        if (userRoles.has(STRIKE_ROLE_IDS.strike2) && nextStrike > 2) await member.roles.remove(STRIKE_ROLE_IDS.strike2);

        await member.roles.add(strikeRole);
        await member.roles.add(MUTE_ROLE_ID);
        await member.timeout(muteDuration, `Strike ${nextStrike} by ${interaction.user.tag} for ${reason}`);

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle(`Strike ${nextStrike} Applied`)
            .setDescription(`${target.tag} has received Strike ${nextStrike} for "${reason}". Muted for ${muteDuration / 60000} minutes.`)
            .setTimestamp()
            .setFooter({ text: `Action by ${interaction.user.tag}` });
        const replyMessage = await interaction.reply({ embeds: [embed] });
        setTimeout(() => {
            replyMessage.delete().catch(error => {
                console.error('Error deleting message:', error);
            });
        }, 8000);

        await logToModChannel(interaction, `Strike ${nextStrike}`, target, muteDuration / 60000, reason);

        setTimeout(async () => {
            await member.timeout(null);
            await member.roles.remove(strikeRole);
            await member.roles.remove(MUTE_ROLE_ID);
            if (nextStrike === 3) {
                const strike1Role = interaction.guild.roles.cache.get(STRIKE_ROLE_IDS.strike1);
                if (strike1Role) await member.roles.add(strike1Role);
            }
        }, muteDuration);
    },
};

async function logToModChannel(interaction, actionType, target, duration, reason) {
    if (!process.env.MOD_LOG_CHANNEL_ID) return;

    const channel = interaction.guild.channels.cache.get(process.env.MOD_LOG_CHANNEL_ID);
    if (!channel) return;

    const embed = new EmbedBuilder()
        .setColor('#000000')
        .setTitle(`${actionType} Logged`)
        .setDescription(
            `**Action**: ${actionType}\n` +
            `**User**: ${target.tag} (ID: ${target.id})\n` +
            `**Moderator**: ${interaction.user.tag} (ID: ${interaction.user.id})\n` +
            `**Duration**: ${duration} minutes\n` +
            `**Reason**: ${reason}\n` +
            `**Time**: ${new Date().toLocaleString('en-US', { timeZone: 'America/New_York' })}`
        )
        .setTimestamp();
    await channel.send({ embeds: [embed] });
}