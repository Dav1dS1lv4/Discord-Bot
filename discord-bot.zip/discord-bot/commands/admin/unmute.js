require('dotenv').config();
const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

const ALLOWED_ROLES = ['']; // Add the ID roles that can use the command.
const MUTE_ROLE_ID = 'MUTED_ID';
const VOICE_MUTED_ROLE_ID = 'VOICE_MUTED_ID';
const LOG_CHANNEL_ID = 'LOG_ID';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unmute')
    .setDescription('Unmutes a user (text and/or voice)')
    .addUserOption(option =>
      option.setName('target')
        .setDescription('User to unmute')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Reason for unmuting')
        .setRequired(false)),

  async execute(interaction) {
    if (!ALLOWED_ROLES.some(r => interaction.member.roles.cache.has(r))) {
      return interaction.reply({ content: 'You do not have permission to use this command.', ephemeral: true });
    }

    const target = interaction.options.getUser('target');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    if (!member) {
      return interaction.reply({ content: 'User not found in the server.', ephemeral: true });
    }

    const changes = [];

    if (member.communicationDisabledUntilTimestamp > Date.now()) {
      await member.timeout(null);
      changes.push('timeout removed');
    }

    if (member.roles.cache.has(MUTE_ROLE_ID)) {
      await member.roles.remove(MUTE_ROLE_ID);
      changes.push('text mute role removed');
    }

    if (member.voice.channel && member.voice.serverMute) {
      await member.voice.setMute(false);
      changes.push('unmuted from voice channel');
    }

    if (member.roles.cache.has(VOICE_MUTED_ROLE_ID)) {
      await member.roles.remove(VOICE_MUTED_ROLE_ID);
      changes.push('voice mute role removed');
    }

    if (changes.length === 0) {
      return interaction.reply({ content: `${target.tag} is already unmuted.`, ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setColor('#00FF00')
      .setTitle('User Unmuted')
      .setDescription(`${target} has been unmuted.\n**Changes**: ${changes.join(', ')}`)
      .addFields({ name: 'Reason', value: reason })
      .setFooter({ text: `By ${interaction.user.tag}` })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });

    const logChannel = interaction.guild.channels.cache.get(LOG_CHANNEL_ID);
    if (logChannel) {
      logChannel.send({
        embeds: [new EmbedBuilder()
          .setColor('#00FF00')
          .setTitle('Unmute Recorded')
          .setDescription(`**User**: ${target.tag} (${target.id})\n**Moderator**: ${interaction.user.tag}\n**Reason**: ${reason}`)
          .setTimestamp()]
      }).catch(() => {});
    }
  }
};