require('dotenv').config();
const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

process.env.MOD_LOG_CHANNEL_ID = '';

const ALLOWED_ROLES = ['']; // Add the ID roles that can use the command.
const STRIKE_ROLE_IDS = {
    strike1: 'STRIKEID1',
    strike2: 'STRIKEID2',
    strike3: 'STRIKEID3'
};
const MUTE_ROLE_ID = 'MUTE_ID';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('removestrike')
        .setDescription('Remove the highest strike from a user and clear any timeout.')
        .addUserOption(option =>
            option.setName('target')
                .setDescription('The user to remove a strike from')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Reason for removing the strike')
                .setRequired(false)),
    async execute(interaction) {
        if (!ALLOWED_ROLES.some(roleId => interaction.member.roles.cache.has(roleId))) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Permission Error')
                .setDescription('You do not have permission to moderate members!')
                .setTimestamp();
            const replyMessage = await interaction.reply({ embeds: [errorEmbed] });
            setTimeout(() => {
                replyMessage.delete().catch(error => {
                    console.error('Error deleting message:', error);
                });
            }, 8000);
            return;
        }

        const target = interaction.options.getUser('target');
        const reason = interaction.options.getString('reason') || 'No reason provided';
        const member = interaction.guild.members.cache.get(target.id);

        if (!member) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('User Not Found')
                .setDescription('The user is not in this server!')
                .setTimestamp();
            const replyMessage = await interaction.reply({ embeds: [errorEmbed] });
            setTimeout(() => {
                replyMessage.delete().catch(error => {
                    console.error('Error deleting message:', error);
                });
            }, 8000);
            return;
        }

        if (!member.moderatable) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Permission Error')
                .setDescription('I do not have permission to moderate this user!')
                .setTimestamp();
            const replyMessage = await interaction.reply({ embeds: [errorEmbed] });
            setTimeout(() => {
                replyMessage.delete().catch(error => {
                    console.error('Error deleting message:', error);
                });
            }, 8000);
            return;
        }

        const userRoles = member.roles.cache;
        let highestStrikeRole = null;
        let strikeLevel = 0;

        if (userRoles.has(STRIKE_ROLE_IDS.strike3)) {
            highestStrikeRole = interaction.guild.roles.cache.get(STRIKE_ROLE_IDS.strike3);
            strikeLevel = 3;
        } else if (userRoles.has(STRIKE_ROLE_IDS.strike2)) {
            highestStrikeRole = interaction.guild.roles.cache.get(STRIKE_ROLE_IDS.strike2);
            strikeLevel = 2;
        } else if (userRoles.has(STRIKE_ROLE_IDS.strike1)) {
            highestStrikeRole = interaction.guild.roles.cache.get(STRIKE_ROLE_IDS.strike1);
            strikeLevel = 1;
        }

        if (!highestStrikeRole) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('No Strike Found')
                .setDescription(`${target.tag} does not have any strike roles!`)
                .setTimestamp();
            const replyMessage = await interaction.reply({ embeds: [errorEmbed] });
            setTimeout(() => {
                replyMessage.delete().catch(error => {
                    console.error('Error deleting message:', error);
                });
            }, 8000);
            return;
        }

        await member.roles.remove(highestStrikeRole);
        if (userRoles.has(MUTE_ROLE_ID)) await member.roles.remove(MUTE_ROLE_ID);
        await member.timeout(null);

        const successEmbed = new EmbedBuilder()
            .setColor('#00FF00')
            .setTitle('Strike Removed')
            .setDescription(`Removed Strike ${strikeLevel} from ${target.tag}, cleared timeout, and removed Muted role.`)
            .addFields(
                { name: 'Reason', value: reason, inline: true },
                { name: 'Moderator', value: interaction.user.tag, inline: true }
            )
            .setTimestamp();

        const replyMessage = await interaction.reply({ embeds: [successEmbed] });
        setTimeout(() => {
            replyMessage.delete().catch(error => {
                console.error('Error deleting message:', error);
            });
        }, 8000);

        await logToModChannel(interaction, 'Remove Strike', target, reason, `Strike ${strikeLevel}`);
    },
};

async function logToModChannel(interaction, actionType, targetUser, reason, strikeLevel) {
    if (!process.env.MOD_LOG_CHANNEL_ID) return;

    const channel = interaction.guild.channels.cache.get(process.env.MOD_LOG_CHANNEL_ID);
    if (!channel) return;

    const embed = new EmbedBuilder()
        .setColor('#000000')
        .setTitle(`${actionType} Logged`)
        .setDescription(
            `**Action**: ${actionType}\n` +
            `**User Affected**: ${targetUser.tag} (ID: ${targetUser.id})\n` +
            `**Moderator**: ${interaction.user.tag} (ID: ${interaction.user.id})\n` +
            `**Strike Removed**: ${strikeLevel}\n` +
            `**Reason**: ${reason}\n` +
            `**Time**: ${new Date().toLocaleString('en-US', { timeZone: 'America/New_York' })}`
        )
        .setTimestamp();
    await channel.send({ embeds: [embed] });
}